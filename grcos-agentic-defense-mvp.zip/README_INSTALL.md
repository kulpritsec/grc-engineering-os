# Install GRC-OS Agentic Defense v0.1 on existing feature branch

Only apply to a clean local checkout of `kulpritsec/grc-engineering-os` on `feat/agentic-defense-foundation`.

1. Unpack the ZIP into the repository root (files are under src/, tests/, examples/, docs/). If using `unzip`, run `unzip -n /path/to/grcos-agentic-defense-mvp.zip` so you never overwrite existing files accidentally. Inspect `git status` before proceeding.
2. Apply CLI patch: `git apply --check add-defense-cli.patch && git apply add-defense-cli.patch`.
3. Run: `uv run ruff format src/grcctl/defense tests/test_defense.py`.
4. Run: `uv run ruff check . && uv run mypy src` with optional FastAPI requirements as previously used.
5. Run full tests: `uv run --no-sync --with-requirements requirements/platform-dev.txt pytest -q`.
6. Run CLI example from docs/AGENTIC_DEFENSE_V0_1.md. Output is local development evidence, *not* an authenticated forensic record.
7. Review `git diff` and commit only after independent tests. No secrets, raw real-world log files, or generated outputs in git.

The ZIP files are only a proposed implementation; they are not a merge/commit and have not been tested in the user's VM.
